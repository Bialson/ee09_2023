<?php 
    $connection = mysqli_connect('localhost', 'root', '', 'firma');
?>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    <title>Sekretariat</title>
</head>
<body>
    <section id="left">
        <h1>Akta Pracownicze</h1>
        <?php 
            $query = "SELECT imie, nazwisko, adres, miasto, czyRODO, czyBadania FROM pracownicy WHERE id=2";
            $result = mysqli_query($connection, $query);
            $workerData = mysqli_fetch_array($result);
            $rodoStatus = ($workerData[4] == 1) ? "podpisano" : "niepodpisano";
            $examineStatus = ($workerData[5] == 1) ? "aktualne" : "nieaktualne";
            echo("
                <h3>dane</h3>
                <p>$workerData[0] $workerData[1]</p>
                <hr>
                <h3>adres</h3>
                <p>$workerData[2]</p>
                <p>$workerData[3]</p>
                <hr>
                <p>RODO: $rodoStatus</p>
                <p>Badania: $examineStatus</p>
            ");
        ?>
        <hr>
        <h3>Dokumenty pracownika</h3>
        <a href="cv.txt">Pobierz</a>
        <h1>Liczba zatrudnionych pracowników</h1>
        <p>
            <?php
                $query = "SELECT COUNT(*) FROM pracownicy";
                $result = mysqli_query($connection, $query);
                echo(mysqli_fetch_array($result)[0]);
            ?>
        </p>
    </section>
    <section id="right">
        <?php
            $query = "SELECT id, imie, nazwisko FROM pracownicy WHERE id=2";
            $result = mysqli_query($connection, $query);
            $workerData = mysqli_fetch_array($result);
            $fileName = $workerData[0].".jpg";
            echo("
                <img src='".$fileName."' alt='pracownik'>
                <h2>$workerData[1] $workerData[2]</h2>
            ");

            $query = "SELECT stanowiska.nazwa, stanowiska.opis FROM stanowiska JOIN pracownicy ON stanowiska.id = pracownicy.stanowiska_id WHERE pracownicy.id=2";
            $result = mysqli_query($connection, $query);
            $workerData = mysqli_fetch_array($result);
            echo("
                <h4>$workerData[0]</h4>
                <h5>$workerData[1]</h5>
            ");
        ?>
    </section>
    <footer>
        Autorem aplikacji jest: 00000000000
        <ul>
            <li>skontaktuj się</li>
            <li>poznaj naszą firmę</li>
        </ul>
    </footer>
</body>
</html>
<?php mysqli_close($connection); ?>